﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DifficulteEnnemi : MonoBehaviour
{
    public int difficulte;

    public int GetDifficulte()
    {

        return difficulte;

    }
}
