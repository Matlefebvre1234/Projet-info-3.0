﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Salle3 : MonoBehaviour
{
    public int hauteur;
    public int largeur;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
