﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FinJeu : MonoBehaviour
{
    public void QuitterJeu()
    {
        Debug.Log("test");
        Application.Quit();
    }
}
