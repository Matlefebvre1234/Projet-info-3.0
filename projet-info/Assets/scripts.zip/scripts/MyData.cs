﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyData
{
    public Vector3 playerPosition;

    public int playerHealth;

}
